import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-payment',
  templateUrl: './member-payment.component.html',
  styleUrls: ['./member-payment.component.css']
})
export class MemberPaymentComponent implements OnInit {
  
  successDialog = 'none';
  networkissue = 'none';
  failuredialog = 'none';
  constructor() {     
  
  }

  ngOnInit() {

  }

  onCloseHandled(){
    this.successDialog = 'none';
    this.networkissue = 'none';
    this.failuredialog = 'none';
  }

}
