﻿export * from './footer.component';
