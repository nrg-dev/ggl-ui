import { Component, OnInit } from '@angular/core';
import { AlertService, AuthenticationService, UserService } from '../_services/index';

@Component({
  selector: 'app-member-payment',
  templateUrl: './member-payment.component.html',
  styleUrls: ['./member-payment.component.css']
})
export class MemberPaymentComponent implements OnInit {
  
  bankList: any = {};  
  bankTransferList:  any ={};

  successDialog = 'none';
  networkissue = 'none';
  failuredialog = 'none';
  public paymentdiv = false;
  public debitdiv = false;
  public creditdiv =  false;
  public nextdetails = false;
  public bankdetails2 = false;

  constructor(
    private authenticationService: AuthenticationService,
    private userService : UserService,
    private alertService: AlertService) {

  }

  ngOnInit() {
    this.paymentdiv = true;
    this.userService.getBankName()
    .subscribe(
        data => {
            this.bankList = data;
        },
        error => {
            this.networkissue = 'block';
        }
    );
  }

  paydebitcard(){
    this.creditdiv = false;
    this.debitdiv = true;
    this.paymentdiv = true;
    this.nextdetails = false;
    this.bankdetails2 = false;
  }

  paycreditcard(){
    this.creditdiv = true;
    this.debitdiv = false;
    this.paymentdiv = false;
    this.nextdetails = false;
    this.bankdetails2 = false;
  }

  closeDialog(){
    this.paymentdiv = true;
    this.debitdiv = false;
    this.creditdiv = false;
    this.nextdetails = false;
    this.bankdetails2 = false;
  }

  onCloseHandled(){
    this.successDialog = 'none';
    this.networkissue = 'none';
    this.failuredialog = 'none';
  }

  afterselect(){
    this.creditdiv = false;
    this.debitdiv = true;
    this.paymentdiv = true;
    this.nextdetails = true;
    this.bankdetails2 = false;
    this.userService.getBankTransferName()
    .subscribe(
        data => {
            this.bankTransferList = data;
        },
        error => {
            this.networkissue = 'block';
        }
    );
  }

  afterselect2(){
    this.creditdiv = false;
    this.debitdiv = true;
    this.paymentdiv = true;
    this.nextdetails = true;
    this.bankdetails2 = true;
  }

}
