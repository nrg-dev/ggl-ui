export class Dropbox {
  countryName:string;
}
