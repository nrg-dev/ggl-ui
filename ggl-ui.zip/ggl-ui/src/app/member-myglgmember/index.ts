﻿export * from './member-myglgmember.component';
